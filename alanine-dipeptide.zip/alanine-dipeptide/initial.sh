
say=0
add=1
for i in {1..27}
do 
mkdir md$i
cd md$i
cp ../phi-psi-ite-1 ./
gmx grompp -f ../grompp.mdp -c ../md$say/md$say.gro -p ../topol.top -o md$i.tpr
say=$(($say+$add))
awk "NR==$say{print;exit}" phi-psi-ite-1 > test.dat
phi=$(awk 'NR == 1 {printf "%f\n",$1}' test.dat)
psi=$(awk 'NR == 1 {printf "%f\n",$2}' test.dat)
rm test.dat

cat >plumed.dat << EOF
phic: TORSION ATOMS=5,7,9,15
psic: TORSION ATOMS=7,9,15,17
#
# Impose an umbrella potential on CV 1
# with a spring constant of 500 kjoule/mol
# at fixed points on the Ramachandran plot
#
restraint-phi: RESTRAINT ARG=phic KAPPA=500 AT=$phi
restraint-psi: RESTRAINT ARG=psic KAPPA=500 AT=$psi
# monitor the two variables and the bias potential from the two restraints
PRINT STRIDE=1 ARG=phic,psic FILE=COLVAR
EOF

gmx mdrun -s md$i.tpr -deffnm md$i -plumed plumed.dat -nsteps 10000 -c md$i.gro -e md$i.edr -g md$i.log -v

cd ..
done
