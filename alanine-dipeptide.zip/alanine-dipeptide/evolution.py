# importing libraries
import numpy as np
import time
import matplotlib.pyplot as plt
from scipy.interpolate import griddata
   


for i in range(1,101):
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.patch.set_edgecolor('black')  ##Border color
    ax.patch.set_linewidth('2.5')  ##Border linewidth
    
    phi=[]
    psi=[]
    fes=[]
    with open("2dfes.dat") as f:
        for line in f:
            cols = line.split()
            if len(cols) == 5:
                phi.append(float(cols[0]))
                psi.append(float(cols[1]))
                fes.append(float(cols[2]))
                
    phi=np.array(phi).astype(np.float)
    psi=np.array(psi).astype(np.float)
    fes=np.array(fes).astype(np.float)
        
    x=np.linspace(phi.min(),phi.max(),100)
    y=np.linspace(psi.min(),psi.max(),100)
    X, Y =np.meshgrid(x,y)
    Z=griddata((phi,psi),fes,(X,Y), method='linear')
        
    plt.contourf(X, Y, Z, 20, cmap='RdYlBu_r') #RdYlBu_r plt.cm.jet
    cbar=plt.colorbar()
    cbar.ax.tick_params(labelsize=20)
    cbar.ax.set_ylabel('Free energy (kJ/mol)', fontsize=20, fontname='Arial')
    
    ax.set_xlabel(r'$\phi$', fontsize=20, fontname='Arial')
    ax.set_ylabel(r'$\psi$', fontsize=20, fontname='Arial')
    plt.xticks(fontsize=20, fontname='Arial') #Xtick size
    plt.yticks(fontsize=20, fontname='Arial') #Ytick size      
    
    
    f=open("phi-psi-ite-" + str(i), 'r')
    lines=f.readlines()
    phi=[]; psi=[];
    for x in lines:
        phi.append(x.split('\t')[0])
        psi.append(x.split('\t')[1])
    f.close()
    
    phi=np.array(phi).astype(np.float)
    psi=np.array(psi).astype(np.float)
    
    plt.plot(phi,psi, 'ko-', lw=1.0, markersize=3.0)
    
    plt.savefig('./evolution/fes'+str(i)+'.png', bbox_inches = 'tight', pad_inches = 0.1,dpi=300)

 
plt.show()
