
import numpy as np

tol=0.000001

f1=open("phi-psi-ite-1","r")
lines1=f1.readlines()
phio=[]
psio=[]
#print(lines)
for x in lines1:
    phio.append(x.split('\t')[0])
    psio.append(x.split('\t')[1])
f1.close()

phio=np.array(phio).astype(np.float)
psio=np.array(psio).astype(np.float)

f=open("phi-psi-ite-2","r")
lines=f.readlines()
phi=[]
psi=[]
#print(lines)
for x in lines:
    phi.append(x.split('\t')[0])
    psi.append(x.split('\t')[1])
f.close()

phi=np.array(phi).astype(np.float)
psi=np.array(psi).astype(np.float)

#***************SMOOTHING*****************#
count=len(phi)
phi_n=np.zeros_like(phi)
psi_n=np.zeros_like(phi)
phi_n[0]=phi[0]
phi_n[-1]=phi[-1]
psi_n[0]=psi[0]
psi_n[-1]=psi[-1]
for i in range (count-2):
    j=(i+1)
    k=(i+2)
    phi_n[j]=((phi[i]+phi[j]+phi[k])/3)
    psi_n[j]=((psi[i]+psi[j]+psi[k])/3)
phi=phi_n
psi=psi_n
#**************END OF SMOOTHING************#

dx=(phi-np.roll(phi,1))
dy=(psi-np.roll(psi,1))

#print(dx)
dx[0]=0
dy[0]=0


lxy=np.zeros_like(phi)
count=len(phi)
for i in range (count):
    lxy[i]=lxy[i-1]+(np.sqrt(pow(dx[i],2)+pow(dy[i],2)))

for i in range (count):
    lxy[i]=lxy[i]/lxy[count-1]
    
inter=np.linspace(0,1,count)
 
phi=np.interp(inter,lxy,phi)
psi=np.interp(inter,lxy,psi)

with open("/home/avijeet/Documents/data/work/SM_maxima/adp/charmm22/272k/phi-psi-ite-2", "w") as myfile:
    for i in range (count):    
        myfile.write("%.11f \t"%phi[i])
        myfile.write("%.11f \n"%psi[i])
        
myfile.close()

diffx=0
diffy=0
#for j in range (count):
diffx += pow((phi-phio),2)
diffy += pow((psi-psio),2)
diffx=sum(diffx)
diffy=sum(diffy)
#print(diffx)
tol_check=(np.sqrt(diffx+diffy))/count
print("tol-check\t")
print(tol_check)
if(tol_check<tol):
    binary=1
else:
    binary=0
print(binary)

with open("/home/avijeet/Documents/data/work/SM_maxima/adp/charmm22/272k/tol_check", "w") as my:
    my.write("%d\n"%binary)
my.close()   

    
