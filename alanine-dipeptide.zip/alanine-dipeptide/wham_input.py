import numpy as np
import matplotlib.pyplot as plt

myfile= open("adp-data.dat", "a")

for count in range(3,11):
    phi=[]; psi=[]
    f=open("phi-psi-ite-" + str(count), 'r')
    lines=f.readlines()
    for x in lines:
        phi.append(x.split('\t')[0])
        psi.append(x.split('\t')[1])
    f.close()
    
    phi=np.array(phi).astype(np.float)
    psi=np.array(psi).astype(np.float)
    
    for i in range(1,(len(phi)-1)):
        myfile.write('/home/avijeet/Documents/data/work/SM_maxima/adp/charmm22/272k/tue/'+'md'+str(i+1)+'/iteration-'+str(count-1)+'/COLVAR\t'+str(phi[i])+'\t'+str(psi[i])+'\t80\t80\n')
    myfile.write('\n')
myfile.close()
