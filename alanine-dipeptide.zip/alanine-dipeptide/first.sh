
#!!---------------------------------!!#
#finding new phi-psi for first iteration

#At inner points on string
for AT in {2..26}
do

cp new.py ./md$AT/.
cd ./md$AT/.

sed -i '/^#/d' COLVAR

python2 new.py

cd ..
done


