
python2 equispacing.py

mkdir phi-psi-ite
mv phi-psi-ite-1 ./phi-psi-ite/
rename -v 's/phi-psi-ite-2/phi-psi-ite-1/' phi-psi-ite-2 phi-psi-ite-1

#!!-----------------------------------------------!!#
#First Iteration at every points on string
ite=1
say=0
add=1
for AT in {2..26}
do

mkdir ./md$AT/iteration-$ite
cp topol.top ./md$AT/iteration-$ite/.
cp grompp.mdp ./md$AT/iteration-$ite/.
cp phi-psi-ite-1 ./md$AT/iteration-$ite/.

cd ./md$AT/
cp md$AT.gro ./iteration-$ite/.
cp new.py ./iteration-$ite/.
cd ./iteration-$ite/

#gmx grompp -f minim.mdp -c md$AT.gro -p topol.top -o em.tpr

#gmx mdrun -deffnm em

gmx grompp -f grompp.mdp -c md$AT.gro -p topol.top -o md$ite.tpr

say=$(($say+$add))

say=$(($say+$add))
awk "NR==$say{print;exit}" phi-psi-ite-1 > test.dat
phi_old=$(awk 'NR == 1 {printf "%f\n",$1}' test.dat)
psi_old=$(awk 'NR == 1 {printf "%f\n",$2}' test.dat)
rm test.dat


cat >plumed.dat << EOF
phi: TORSION ATOMS=5,7,9,15
psi: TORSION ATOMS=7,9,15,17
#
# Impose an umbrella potential on CV 1
# with a spring constant of 500 kjoule/mol
# at fixed points on the Ramachandran plot
#
restraint-phi: RESTRAINT ARG=phi KAPPA=80 AT=$phi_old
restraint-psi: RESTRAINT ARG=psi KAPPA=80 AT=$psi_old
# monitor the two variables and the bias potential from the two restraints
PRINT STRIDE=1 ARG=phi,psi,restraint-phi.bias,restraint-psi.bias,restraint-phi.force2,restraint-psi.force2, FILE=COLVAR
EOF

gmx mdrun -s md$ite.tpr -deffnm md$ite -plumed plumed.dat -nsteps 100000 -c md$ite.gro -e md$ite.edr -g md$ite.log -v

FILE="md$ite.gro"
 
if [ -f "$FILE" ];
then
   echo "File $FILE exist."
else
   echo "File $FILE does not exist" >&2
   cd ../..
   cp grompp2.mdp ./md_phi$AT/iteration-$ite/.
   cd ./md_phi$AT/iteration-$ite/
   gmx grompp -f grompp2.mdp -c em.gro -p topol.top -o md$ite.tpr
   gmx mdrun -s md$ite.tpr -deffnm md$ite -plumed plumed.dat -nsteps 100000 -c md$ite.gro -e md$ite.edr -g md$ite.log
fi

sed -i '/^#/d' COLVAR

say=$(echo $(( say-add )))

> new-values
python2 new.py

cd ../..

done
