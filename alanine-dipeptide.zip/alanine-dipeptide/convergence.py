import numpy as np
import matplotlib.pyplot as plt

num=100      #Number of iterations
rows=27 #Number of points on the string
phi=[]; psi=[];
for count in range(1,(num+1)):
    f=open("phi-psi-ite-" + str(count), 'r')
    lines=f.readlines()
    for x in lines:
        phi.append(x.split('\t')[0])
        psi.append(x.split('\t')[1])
    f.close()
    
phi=np.array(phi).astype(np.float)
psi=np.array(psi).astype(np.float)

sigma_x=[]
sigma_y=[]

for j in range(rows,(num*rows),rows): #loop over the iterations (first value of phi-psi)
    sigma_xx=0
    sigma_yy=0
    for i in range(j,(j+rows)): #loop over a point on string (startuing from first value to the last value)
        sigma_xx=sigma_xx+np.abs(phi[i]-phi[(i-rows)])
        sigma_yy=sigma_yy+np.abs(psi[i]-psi[(i-rows)])
    
    sigma_x.append((sigma_xx)/rows)
    sigma_y.append((sigma_yy)/rows)

with open("adp_convergence.dat", "a") as myf:
    for i in range (0,len(sigma_x),1):    
        myf.write("%.11f \t"%sigma_x[i])
        myf.write("%.11f \n"%sigma_y[i])
myf.close()

#sigma_x = [x * 100000 for x in sigma_x]

#sigma_x=np.log(sigma_x)
#sigma_y=np.log(sigma_y)
fig=plt.figure(figsize=(9,10))
plt.subplot(2,1,1)
plt.plot(sigma_x, 'ko-', label='S')
plt.xlabel("Iteration Number",fontsize=20)
plt.ylabel("Convergence", fontsize=20)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.legend()

plt.subplot(2,1,2)
plt.plot(sigma_y, 'ro-', label='Z')
plt.xlabel("Iteration Number",fontsize=20)
plt.ylabel("Convergence", fontsize=20)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.legend()
plt.savefig('convergence.png', dpi=300)


